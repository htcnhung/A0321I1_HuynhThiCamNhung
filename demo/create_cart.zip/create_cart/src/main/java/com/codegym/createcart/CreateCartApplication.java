package com.codegym.createcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreateCartApplication {

    public static void main(String[] args) {
        SpringApplication.run(CreateCartApplication.class, args);
    }

}
